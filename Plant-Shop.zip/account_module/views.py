from django.http import HttpResponse
from django.views import generic
import logging
from django.contrib.auth import get_user_model
from .models import User
from .forms.registration import UserRegistrationForm, UserProfileForm
from .forms.auth import(
    CustomAuthenticationForm, CustomPasswordChangeForm,
    CustomPasswordResetForm, CustomSetPasswordForm
)
from .services.email_verification import EmailVerificationService
from django.contrib import messages
from django.utils.translation import gettext_lazy as _
from django.shortcuts import redirect, render
from django.contrib.auth import login
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django.contrib.auth.views import (
    PasswordResetView, PasswordResetConfirmView,
    PasswordResetDoneView, PasswordResetCompleteView
)
from django.conf import settings



logger = logging.getLogger(__name__)
user = get_user_model()

class BaseViewMixin:
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['current_page'] = self.request.resolver_match.url_name
        return context
    
    def handle_exception(self, exc):
        logger.error(f'Error in {self.__class__.__name__}: {str(exc)}')
        return super().handle_exception(exc)
    


class UserRegistrationView(generic.CreateView):
    model = User
    form_class = UserRegistrationForm
    template_name = 'account_module/register.html'
    success_url = reverse_lazy('home-page')

    def form_valid(self, form):
        response = super().form_valid(form)
        user = form.save()

        if EmailVerificationService.send_verification_email(user):
            messages.success(
                self.request,
                _('Registration successful. Please check your email for verification.')
            )
        else:
            messages.warning(
                self.request,
                _('Registration successful, but we could not send the verification email. Please try again later.')
            )
        return response 
    
    def form_invalid(self, form):
        messages.error(
            self.request,
            _('Registration failed. Please check the form and try again.')
        )
        return super().form_invalid(form)


class CustomLoginView(generic.View):
    template_name = ''
    form_class = CustomAuthenticationForm


    def get(self, request):
        if request.user.is_authenticated:
            return redirect('login')
        return self.render_form()    
    
    def post(self, request):
        form = self.form_class(request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            
            user.last_login_ip = self.get_client_ip(request)
            user.save(update_fields=['last_login_ip'])

            next_url = request.GET.get('next', 'home')
            return redirect(next_url)
        
        return self.render_form(form)


    def get_client_ip(self, request):
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = request.META.get('REMOTE_ADDR')
        return ip

    def render_form(self, form=None):
        if form is None:
            form = self.form_class()
        return render(self.request, self.template_name, {'form': form})


class UserProfileView(LoginRequiredMixin, BaseViewMixin, generic.UpdateView):

    model = User
    form_class = UserProfileForm
    template_name = ''
    success_url = reverse_lazy('')

    def get_object(self, queryset = None):
        return self.request.user
    
    @method_decorator(cache_page(60 * 15))
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    def form_valid(self, form):
        messages.success(self.request, _('Profile updated successfully'))
        return super().form_valid(form)    


class PasswordChangeView(LoginRequiredMixin, generic.UpdateView):
    form_class = CustomPasswordChangeForm
    template_name = ''
    success_url = reverse_lazy('')

    def get_object(self, queryset = None):
        return self.request.user
    
    def form_valid(self, form):
        form.save()
        messages.success(self.request, _('Password changed successfully'))
        return super().form_valid(form)
    

class CustomPasswordResetView(PasswordResetView):



    form_class = CustomPasswordResetForm
    template_name = ''
    email_template_name = ''
    subject_template_name = ''
    success_url = reverse_lazy('')

    def form_valid(self, form):
        form.save(
            request = self.request,
            use_https = self.request.is_secure(),
            from_email=settings.DEFAULT_FROM_EMAIL, 
            email_template_name = self.email_template_name,
            subject_template_name = self.subject_template_name

        )

        messages.success(
            self.request,
            _('If an account exists with this email, you will receive password reset instructions.')
        )

        return super().form_valid(form)
    

class CustomPasswordResetDoneView(PasswordResetDoneView):
    template_name = 'account/password_reset_done.html'


class CustomPasswordResetConfirmView(PasswordResetConfirmView):
    form_class = CustomSetPasswordForm
    template_name = ''
    success_url = reverse_lazy('')

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(
            self.request,
            _('Your password has been reset successfully.')
        )
        return response
    

class CustomPasswordResetCompleteView(PasswordResetCompleteView):
    template_name = 'account/password_reset_complete.html'